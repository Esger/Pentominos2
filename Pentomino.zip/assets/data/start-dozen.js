[
    {
        "name": "b",
        "face": 4,
        "position": {
            "x": 6,
            "y": 0
        }
    },
    {
        "name": "c",
        "face": 0,
        "position": {
            "x": 3,
            "y": 0
        }
    },
    {
        "name": "f",
        "face": 2,
        "position": {
            "x": 2,
            "y": 3
        }
    },
    {
        "name": "i",
        "face": 1,
        "position": {
            "x": 2,
            "y": 0
        }
    },
    {
        "name": "l",
        "face": 1,
        "position": {
            "x": 8,
            "y": 4
        }
    },
    {
        "name": "n",
        "face": 6,
        "position": {
            "x": 3,
            "y": 6
        }
    },
    {
        "name": "t",
        "face": 1,
        "position": {
            "x": 5,
            "y": 4
        }
    },
    {
        "name": "v",
        "face": 3,
        "position": {
            "x": 6,
            "y": 5
        }
    },
    {
        "name": "w",
        "face": 0,
        "position": {
            "x": 6,
            "y": 1
        }
    },
    {
        "name": "x",
        "face": 0,
        "position": {
            "x": 3,
            "y": 1
        }
    },
    {
        "name": "y",
        "face": 2,
        "position": {
            "x": 8,
            "y": 0
        }
    },
    {
        "name": "z",
        "face": 2,
        "position": {
            "x": 2,
            "y": 5
        }
    }
]
