[
    {
        "name": "b",
        "face": 4,
        "position": {
            "x": 3,
            "y": 1
        }
    },
    {
        "name": "c",
        "face": 0,
        "position": {
            "x": 0,
            "y": 1
        }
    },
    {
        "name": "f",
        "face": 2,
        "position": {
            "x": -1,
            "y": 4
        }
    },
    {
        "name": "i",
        "face": 1,
        "position": {
            "x": -1,
            "y": 1
        }
    },
    {
        "name": "l",
        "face": 1,
        "position": {
            "x": 5,
            "y": 5
        }
    },
    {
        "name": "n",
        "face": 6,
        "position": {
            "x": 0,
            "y": 7
        }
    },
    {
        "name": "t",
        "face": 1,
        "position": {
            "x": 2,
            "y": 5
        }
    },
    {
        "name": "v",
        "face": 3,
        "position": {
            "x": 3,
            "y": 6
        }
    },
    {
        "name": "w",
        "face": 0,
        "position": {
            "x": 3,
            "y": 2
        }
    },
    {
        "name": "x",
        "face": 0,
        "position": {
            "x": 0,
            "y": 2
        }
    },
    {
        "name": "y",
        "face": 2,
        "position": {
            "x": 5,
            "y": 1
        }
    },
    {
        "name": "z",
        "face": 2,
        "position": {
            "x": -1,
            "y": 6
        }
    }
]
