[
    {
        "name" : "b",
        "face" : 7,
        "position" : {
            "x" : 5,
            "y" : 0
        }
    },{
        "name" : "c",
        "face" : 2,
        "position" : {
            "x" : 8,
            "y" : 5
        }
    },{
        "name" : "f",
        "face" : 1,
        "position" : {
            "x" : 6,
            "y" : 1
        }
    },{
        "name" : "i",
        "face" : 0,
        "position" : {
            "x" : 5,
            "y" : 9
        }
    },{
        "name" : "l",
        "face" : 1,
        "position" : {
            "x" : 9,
            "y" : 0
        }
    },{
        "name" : "n",
        "face" : 4,
        "position" : {
            "x" : 6,
            "y" : 7
        }
    },{
        "name" : "t",
        "face" : 1,
        "position" : {
            "x" : 8,
            "y" : 7
        }
    },{
        "name" : "v",
        "face" : 2,
        "position" : {
            "x" : 5,
            "y" : 3
        }
    },{
        "name" : "w",
        "face" : 2,
        "position" : {
            "x" : 7,
            "y" : 0
        }
    },{
        "name" : "x",
        "face" : 0,
        "position" : {
            "x" : 8,
            "y" : 3
        }
    },{
        "name" : "y",
        "face" : 6,
        "position" : {
            "x" : 5,
            "y" : 5
        }
    },{
        "name" : "z",
        "face" : 3,
        "position" : {
            "x" : 5,
            "y" : 4
        }
    },{
        "name" : "o",
        "face" : 0,
        "position" : {
            "x" : 7,
            "y" : 10
        }
    }
]
