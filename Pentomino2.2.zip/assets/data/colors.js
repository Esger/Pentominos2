colors = [
    {
        "name": "b",
        "color": "midnightblue"
    }, {
        "name": "c",
        "color": "darkviolet"
    }, {
        "name": "f",
        "color": "darkorange"
    }, {
        "name": "i",
        "color": "maroon"
    }, {
        "name": "l",
        "color": "darkgreen"
    }, {
        "name": "n",
        "color": "magenta"
    }, {
        "name": "t",
        "color": "limegreen"
    }, {
        "name": "v",
        "color": "deepskyblue"
    }, {
        "name": "w",
        "color": "teal"
    }, {
        "name": "x",
        "color": "red"
    }, {
        "name": "y",
        "color": "gold"
    }, {
        "name": "z",
        "color": "mediumblue"
    }, {
        "name": "o",
        "color": "darkslategray"
    }
];
